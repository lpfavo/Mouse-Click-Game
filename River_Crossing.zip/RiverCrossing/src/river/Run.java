/**
 * Author:Yongdi Liu  
 * Student ID:16723023
 * Date:May 30th,2018
 * Description:This main function is to run the game. 
 * Warn: This game was developed in the JDK 10.0.1. Most of function can be run in other JDK version. If it does not work, please run in JDK 10.0.1
 */

package river;

public class Run {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Bottom bottom =new Bottom();
	}

}
